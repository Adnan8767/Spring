package com.springcore.ci;

public class Dept {
	String Name;
	
	public Dept(String Name) {
		this.Name = Name;
	}
}
