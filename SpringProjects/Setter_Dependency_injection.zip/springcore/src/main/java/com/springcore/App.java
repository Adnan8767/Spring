package com.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Project-1 Setter dependency injection 
 *
 */
public class App 
{
    public static void main( String[] args )
    {
		ApplicationContext ap = new ClassPathXmlApplicationContext("config.xml");
        Student s =  (Student)ap.getBean("Student1");
        System.out.println(s);
        
    }
}


