package com.springcore.lifecycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	public static void main(String[] args) {
		// We used AbstractApplicationContext here instead of ApplicationContext because
		// ApplicationContext is child interface of class used below and it does not
		// have registerShutdownHook method
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("com/springcore/lifecycle/config.xml");
		Samosa s = (Samosa) context.getBean("s1");
		System.out.println(s);

		// This will call destroy method
		context.registerShutdownHook();

	}
}
